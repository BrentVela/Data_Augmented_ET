import sklearn.datasets
import sklearn.metrics
import matplotlib.pyplot as plt
from sklearn.gaussian_process import GaussianProcessRegressor
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn import preprocessing
from sklearn.gaussian_process.kernels import WhiteKernel, DotProduct, RBF
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import LabelEncoder
import random
from scipy.stats import kendalltau
from scipy.stats import spearmanr
import time

start_time = time.time()
#Clean features and target


def hgpr(df_train, df_test, feats_w, feats_d, kernel_w, kernel_d):
    
    X1_train = df_train[feats_w]
    X1_test = df_test[feats_w]
    
    y1_test = np.array(df_test['Exp_W'])
    y1_train = np.array(df_train['Exp_W'])

    y1_prior_test = np.array(df_test['ET_width']) * p
    y1_prior_train = np.array(df_train['ET_width']) * p
    
    beta1_train = y1_train - y1_prior_train
    sclr_X = preprocessing.MinMaxScaler(feature_range=(0, 100))
    X1_train = sclr_X.fit_transform(X1_train)
    X1_test = sclr_X.transform(X1_test)
    gpr1 = GaussianProcessRegressor(kernel=kernel_w, n_restarts_optimizer=10, normalize_y=True,
                                   optimizer='fmin_l_bfgs_b',
                                   random_state=30)

    gpr1.fit(X1_train, beta1_train)
    
    beta1_test_pred = gpr1.predict(X1_test)
    y1_test_pred = beta1_test_pred + y1_prior_test
    
    beta1_train_pred = gpr1.predict(X1_train)
    y1_train_pred = beta1_train_pred + y1_prior_train
    
    MAE_w_Test = mean_absolute_error(y1_test, y1_test_pred)
    RMSE_w_Test = np.sqrt(mean_squared_error(y1_test, y1_test_pred))
    Tau_w_Test = kendalltau(y1_test, y1_test_pred).correlation
    RS_w_Test = spearmanr(y1_test, y1_test_pred).correlation
    MAPE_w_Test = np.mean(np.abs((y1_test - y1_test_pred) / y1_test)) * 100

    
    MAE_w_Train = mean_absolute_error(y1_train, y1_train_pred)
    RMSE_w_Train = np.sqrt(mean_squared_error(y1_train, y1_train_pred))
    Tau_w_Train = kendalltau(y1_train, y1_train_pred).correlation


    
    ######### Depth #########
    df2_train = df_train.dropna(subset=['Exp_D'])
    df2_test = df_test.dropna(subset=['Exp_D'])

    df2_train['Proxy'] = gpr1.predict(sclr_X.transform(df2_train[feats_w])) + df2_train['ET_width']
    df2_test['Proxy'] = gpr1.predict(sclr_X.transform(df2_test[feats_w])) + df2_test['ET_width']

    #feats_d = ['P',  'TL', 'K_LT', 'Cp_LT', 'Density_RT', 'Absorptivity', 'Proxy']

    # X2_train = df2_train[feats_d+['Proxy']]
    # X2_test = df2_test[feats_d+['Proxy']]

    X2_train = df2_train[feats_d]
    X2_test = df2_test[feats_d]
    
    y2_test = np.array(df2_test['Exp_D'])
    y2_train = np.array(df2_train['Exp_D'])

    y2_prior_test = np.array(df2_test['ET_depth']) * p
    y2_prior_train = np.array(df2_train['ET_depth']) * p
    
    
    beta2_train = y2_train - y2_prior_train
    sclr_X = preprocessing.MinMaxScaler(feature_range=(0, 100))
    X2_train = sclr_X.fit_transform(X2_train)
    X2_test = sclr_X.transform(X2_test)
    gpr2 = GaussianProcessRegressor(kernel=kernel_d, n_restarts_optimizer=10, normalize_y=True,
                                   optimizer='fmin_l_bfgs_b',
                                   random_state=30)

    gpr2.fit(X2_train, beta2_train)
    
    beta2_test_pred = gpr2.predict(X2_test)
    y2_test_pred = beta2_test_pred + y2_prior_test
    y2_test_pred[y2_test_pred < 0] = 0
    
    beta2_train_pred = gpr2.predict(X2_train)
    y2_train_pred = beta2_train_pred + y2_prior_train
    y2_train_pred[y2_train_pred < 0] = 0
    
    
    MAE_d_Test = mean_absolute_error(y2_test, y2_test_pred)
    RMSE_d_Test = np.sqrt(mean_squared_error(y2_test, y2_test_pred))
    Tau_d_Test = kendalltau(y2_test, y2_test_pred).correlation
    RS_d_Test = spearmanr(y2_test, y2_test_pred).correlation

    MAE_d_Train = mean_absolute_error(y2_train, y2_train_pred)
    RMSE_d_Train = np.sqrt(mean_squared_error(y2_train, y2_train_pred))
    Tau_d_Train = kendalltau(y2_train, y2_train_pred).correlation
    RS_d_Train = spearmanr(y2_train, y2_prior_train).correlation


    
    return MAPE_w_Test, MAE_w_Test, RMSE_w_Test, Tau_w_Test, MAE_w_Train, RMSE_w_Train, Tau_w_Train, MAE_d_Test, RMSE_d_Test, Tau_d_Test, MAE_d_Train, RMSE_d_Train, Tau_d_Train, RS_d_Test,RS_w_Test
    
#Read all the dataframe
df = pd.read_excel('/data/Aug_ET_Public_Database.xlsx')
# df['ET_width'] = 0
# df['ET_depth'] = 0
#Extract the unique compositions
unique_compositions = df['Composition'].unique().tolist()
#Specify the number of compositions in the training set
n = [10]
#Define the features
feats_d = ['P','v',	'T_liquidus',	'thermal_cond_liq',	'Density_kg/m3',	'Cp_J/kg', 'Absorptivity']
feats_w = ['P','v',	'T_liquidus',	'thermal_cond_liq',	'Density_kg/m3',	'Cp_J/kg', 'Absorptivity']



MAE_list_w_Test = []
RMSE_list_w_Test = []
Tau_list_w_Test = []
MAE_list_w_Train = []
RMSE_list_w_Train = []
Tau_list_w_Train = []
MAPE_list_w_Test = []


MAE_list_d_Test = []
RMSE_list_d_Test = []
Tau_list_d_Test = []
MAE_list_d_Train = []
RMSE_list_d_Train = []
Tau_list_d_Train = []
RS_list_d_Test = []
RS_list_w_Test = []

kernel_w =  RBF(length_scale= [1,1,1,1,1,1,1])+ DotProduct() + WhiteKernel()  #Ones like the number of features for anisotropic kern.

kernel_d =  RBF(length_scale= [1,1,1,1,1,1,1])+ DotProduct() + WhiteKernel()  #Ones like the number of features for anisotropic kern.
# Prior?
p = 1
# df['ET_width'] = 0
# df['ET_depth'] = 0

for j in n:
    
    for i in range(100):
        print('Entering loop {}'.format(i+1))
        selected_compositions = random.sample(unique_compositions, j)
        
        df_train = df[df['Composition'].isin(selected_compositions)]
        df_test = df[~df['Composition'].isin(selected_compositions)]
        print(len(df_train), len(df_test))
        MAPE_w_Test, MAE_w_Test, RMSE_w_Test, Tau_w_Test, MAE_w_Train, RMSE_w_Train, Tau_w_Train, MAE_d_Test, RMSE_d_Test,\
        Tau_d_Test, MAE_d_Train, RMSE_d_Train,\
        Tau_d_Train, RS_d_Test,RS_w_Test = hgpr(df_train=df_train, df_test=df_test, feats_w=feats_w,feats_d=feats_d, kernel_w= kernel_w, kernel_d=kernel_d)
        MAE_list_w_Test.append(MAE_w_Test)
        RMSE_list_w_Test.append(RMSE_w_Test)
        Tau_list_w_Test.append(Tau_w_Test)
        MAE_list_w_Train.append(MAE_w_Train)
        RMSE_list_w_Train.append(RMSE_w_Train)
        Tau_list_w_Train.append(Tau_w_Train)
        MAPE_list_w_Test.append(MAPE_w_Test)

    
        MAE_list_d_Test.append(MAE_d_Test)
        RMSE_list_d_Test.append(RMSE_d_Test)
        Tau_list_d_Test.append(Tau_d_Test)
        MAE_list_d_Train.append(MAE_d_Train)
        RMSE_list_d_Train.append(RMSE_d_Train)
        Tau_list_d_Train.append(Tau_d_Train)
        RS_list_d_Test.append(RS_d_Test)
        RS_list_w_Test.append(RS_w_Test)
        print('Done loop {}'.format(i+1))
        
    error_df = pd.DataFrame()

    error_df['MAE_w_Test'] = MAE_list_w_Test
    error_df['RMSE_w_Test'] = RMSE_list_w_Test
    error_df['Tau_w_Test'] = Tau_list_w_Test
    error_df['RS_w_Test'] = RS_list_w_Test
    error_df['MAPE_w_Test'] = MAPE_list_w_Test

    # error_df['MAE_w_Train'] = MAE_list_w_Train
    # error_df['RMSE_w_Train'] = RMSE_list_w_Train
    # error_df['Tau_w_Train'] = Tau_list_w_Train

    # error_df['MAE_d_Test'] = MAE_list_d_Test
    # error_df['RMSE_d_Test'] = RMSE_list_d_Test
    # error_df['Tau_d_Test'] = Tau_list_d_Test
    # error_df['RS_d_Test'] = RS_list_d_Test

    # error_df['MAE_d_Train'] = MAE_list_d_Train
    # error_df['RMSE_d_Train'] = RMSE_list_d_Train
    # error_df['Tau_d_Train'] = Tau_list_d_Train
    
error_df.to_excel('/results/Case3_{}_GPR_Results_W.xlsx'.format(j), index=False)

end_time = time.time()
execution_time = end_time - start_time

print(f"Execution time in seconds: {execution_time:.6f}")
