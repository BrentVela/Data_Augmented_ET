
#%%
import pandas as pd
import matplotlib.pyplot as plt


# Read the CSV files
error_df1 = pd.read_excel('/results/Case1_10_GPR_Results_W.xlsx')
error_df2 = pd.read_excel('/results/Case2_10_GPR_Results_W.xlsx')
error_df3 = pd.read_excel('/results/Case3_10_GPR_Results_W.xlsx')

# Colors for each box
box_colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']  # Blue, Green, Red, Orange, Purple

# Create subplots with a 2x2 grid
fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(10, 8))

# Subplot 1 (MAPE)
boxes_mape = axes[0, 0].boxplot([error_df1['MAE_w_Test'], error_df2['MAE_w_Test'], error_df3['MAE_w_Test']],
                                labels=['1', '2', '3'],
                                patch_artist=True,showfliers = False)

# Set color for each box in MAPE subplot
for box, color in zip(boxes_mape['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 0].set_title('MAE')

# Subplot 2 (RMSE)
boxes_rmse = axes[0, 1].boxplot([error_df1['RMSE_w_Test'], error_df2['RMSE_w_Test'], error_df3['RMSE_w_Test']],
                                labels=['1', '2', '3'],
                                patch_artist=True,showfliers = False)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 1].set_title('RMSE')

# Subplot 3 (Tau)
boxes_fifth_metric = axes[0, 2].boxplot([error_df1['MAPE_w_Test'], error_df2['MAPE_w_Test'], error_df3['MAPE_w_Test']],
                                       labels=['1', '2', '3'],
                                       patch_artist=True,showfliers = False)

# Set color for each box in the fifth metric subplot
for box, color in zip(boxes_fifth_metric['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 2].set_title('MAPE')

# Subplot 4 (Another Metric)
boxes_rmse = axes[1, 0].boxplot([error_df1['Tau_w_Test'], error_df2['Tau_w_Test'], error_df3['Tau_w_Test']],
                                labels=['1', '2', '3'],
                                patch_artist=True)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[1, 0].set_title('Tau')

# Subplot 5 (Fifth Metric)
boxes_rmse = axes[1, 1].boxplot([error_df1['RS_w_Test'], error_df2['RS_w_Test'], error_df3['RS_w_Test']],
                                labels=['1', '2', '3'],
                                patch_artist=True)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[1, 1].set_title('Rs_Distribution')


# Remove the empty subplot in the bottom right
fig.delaxes(axes[1, 2])

# Create a legend for the entire plot
handles = [plt.Rectangle((0,0),1,1, color=color) for color in box_colors]
labels = ['Case 1', 'Case 2', 'Case 3']
plt.legend(handles, labels, loc='upper right', bbox_to_anchor=(1.25, 1))


# Adjust layout for better spacing
plt.tight_layout()
plt.savefig('/results/Figure_10_from_Paper.png')
# Display the plot
