import os
import pandas as pd
import matplotlib.pyplot as plt

# Set the working directory to the script's directory
filepath = os.path.abspath(__file__)
current_path = os.path.split(filepath)[0]
os.chdir(current_path)

# Read the CSV files
error_df1 = pd.read_excel('/results/Case1_10_GPR_Results_D.xlsx')
error_df2 = pd.read_excel('/results/Case2_10_GPR_Results_D.xlsx')
error_df3 = pd.read_excel('/results/Case3_10_GPR_Results_D.xlsx')
error_df4 = pd.read_excel('/results/Case4_10_GPR_Results_D.xlsx')
error_df5 = pd.read_excel('/results/Case5_10_GPR_Results_D.xlsx')



labels = ['1', '2', '3', '4', '5']
# Colors for each box
box_colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']  # Blue, Green, Red, Orange, Purple

# Create subplots with a 2x2 grid
fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(10, 8))

# Subplot 1 (MAPE)
boxes_mape = axes[0, 0].boxplot([error_df1['MAE_d_Test'], error_df2['MAE_d_Test'], error_df3['MAE_d_Test'], error_df4['MAE_d_Test'], error_df5['MAE_d_Test']],
                                labels=labels,
                                patch_artist=True,showfliers = False)

# Set color for each box in MAPE subplot
for box, color in zip(boxes_mape['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 0].set_title('MAE')

# Subplot 2 (RMSE)
boxes_rmse = axes[0, 1].boxplot([error_df1['RMSE_d_Test'], error_df2['RMSE_d_Test'], error_df3['RMSE_d_Test'], error_df4['RMSE_d_Test'], error_df5['RMSE_d_Test']],
                                labels=labels,
                                patch_artist=True,showfliers = False)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 1].set_title('RMSE')

# Subplot 3 (Tau)
boxes_fifth_metric = axes[0, 2].boxplot([error_df1['MAPE_d_Test'], error_df2['MAPE_d_Test'], error_df3['MAPE_d_Test'], error_df4['MAPE_d_Test'], error_df5['MAPE_d_Test']],
                                       labels=labels,
                                       patch_artist=True,showfliers = False)

# Set color for each box in the fifth metric subplot
for box, color in zip(boxes_fifth_metric['boxes'], box_colors):
    box.set_facecolor(color)

axes[0, 2].set_title('MAPE')

# Subplot 4 (Another Metric)
boxes_rmse = axes[1, 0].boxplot([error_df1['Tau_d_Test'], error_df2['Tau_d_Test'], error_df3['Tau_d_Test'], error_df4['Tau_d_Test'], error_df5['Tau_d_Test']],
                                labels=labels,
                                patch_artist=True,showfliers = False)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[1, 0].set_title('Tau')

# Subplot 5 (Fifth Metric)
boxes_rmse = axes[1, 1].boxplot([error_df1['RS_d_Test'], error_df2['RS_d_Test'], error_df3['RS_d_Test'], error_df4['RS_d_Test'], error_df5['RS_d_Test']],
                                labels=labels,
                                patch_artist=True,showfliers = False)

# Set color for each box in RMSE subplot
for box, color in zip(boxes_rmse['boxes'], box_colors):
    box.set_facecolor(color)

axes[1, 1].set_title('Rs_Distribution')


# Remove the empty subplot in the bottom right
fig.delaxes(axes[1, 2])

# Create a legend for the entire plot
handles = [plt.Rectangle((0,0),1,1, color=color) for color in box_colors]
labels = labels
plt.legend(handles, labels, loc='upper right', bbox_to_anchor=(1.25, 1))


# Adjust layout for better spacing
plt.tight_layout()
plt.savefig('/results/Figure_11_from_Paper.png', dpi=1200)
# Display the plot
plt.show()
